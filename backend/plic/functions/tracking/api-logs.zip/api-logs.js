var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// api-logs.ts
var api_logs_exports = {};
__export(api_logs_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_logs_exports);
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var dynamoClient = new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION || "ap-northeast-2" });
var docClient = import_lib_dynamodb.DynamoDBDocumentClient.from(dynamoClient);
var API_LOGS_TABLE = process.env.API_LOGS_TABLE || "plic-api-logs";
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,OPTIONS"
};
var response = (statusCode, body) => ({
  statusCode,
  headers: corsHeaders,
  body: JSON.stringify(body)
});
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return response(200, {});
  }
  try {
    const queryParams = event.queryStringParameters || {};
    const { logId, correlationId, status, limit = "100", offset = "0" } = queryParams;
    if (logId) {
      const result2 = await docClient.send(new import_lib_dynamodb.GetCommand({
        TableName: API_LOGS_TABLE,
        Key: { logId }
      }));
      if (!result2.Item) {
        return response(404, { success: false, error: "\uB85C\uADF8\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." });
      }
      return response(200, { success: true, data: { log: result2.Item } });
    }
    if (correlationId) {
      const result2 = await docClient.send(new import_lib_dynamodb.QueryCommand({
        TableName: API_LOGS_TABLE,
        IndexName: "correlationId-index",
        KeyConditionExpression: "correlationId = :cid",
        ExpressionAttributeValues: { ":cid": correlationId }
      }));
      return response(200, {
        success: true,
        data: {
          logs: result2.Items || [],
          count: result2.Items?.length || 0
        }
      });
    }
    let filterExpression;
    let expressionValues = {};
    if (status === "error") {
      filterExpression = "statusCode >= :errorCode";
      expressionValues[":errorCode"] = 400;
    } else if (status === "slow") {
      filterExpression = "executionTime > :slowTime";
      expressionValues[":slowTime"] = 3e3;
    }
    const result = await docClient.send(new import_lib_dynamodb.ScanCommand({
      TableName: API_LOGS_TABLE,
      FilterExpression: filterExpression,
      ExpressionAttributeValues: Object.keys(expressionValues).length > 0 ? expressionValues : void 0,
      Limit: parseInt(limit, 10)
    }));
    const logs = result.Items || [];
    logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    const allLogs = logs;
    const stats = {
      total: allLogs.length,
      success: allLogs.filter((l) => l.statusCode < 400).length,
      clientError: allLogs.filter((l) => l.statusCode >= 400 && l.statusCode < 500).length,
      serverError: allLogs.filter((l) => l.statusCode >= 500).length,
      avgExecutionTime: allLogs.length > 0 ? Math.round(allLogs.reduce((sum, l) => sum + (l.executionTime || 0), 0) / allLogs.length) : 0
    };
    const endpointErrors = {};
    allLogs.filter((l) => l.statusCode >= 400).forEach((l) => {
      const endpoint = l.endpoint || "unknown";
      endpointErrors[endpoint] = (endpointErrors[endpoint] || 0) + 1;
    });
    const topErrors = Object.entries(endpointErrors).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([endpoint, count]) => ({ endpoint, count }));
    return response(200, {
      success: true,
      data: {
        logs: logs.slice(0, parseInt(limit, 10)),
        stats,
        topErrors,
        hasMore: result.LastEvaluatedKey !== void 0
      }
    });
  } catch (error) {
    console.error("API \uB85C\uADF8 \uC870\uD68C \uC624\uB958:", error);
    return response(500, {
      success: false,
      error: error.message || "API \uB85C\uADF8 \uC870\uD68C \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4."
    });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
