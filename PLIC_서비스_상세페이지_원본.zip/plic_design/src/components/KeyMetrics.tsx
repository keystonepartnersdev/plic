export function KeyMetrics() {
  // Integrated into Hero section
  return null;
}
