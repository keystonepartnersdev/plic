
  # PLIC 서비스 상세페이지

  This is a code bundle for PLIC 서비스 상세페이지. The original project is available at https://www.figma.com/design/wtLK5mn3IK5AZU04L2JfC1/PLIC-%EC%84%9C%EB%B9%84%EC%8A%A4-%EC%83%81%EC%84%B8%ED%8E%98%EC%9D%B4%EC%A7%80.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  